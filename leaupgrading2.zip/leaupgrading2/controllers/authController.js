const User = require("../models/user");
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { dataValid } = require("../utils/dataValidation");

const register = async (req, res) => {
    const valid = {
        username: "required",
        password: "required",
        confirmPassword: "required",
        email: "required,isEmail",
        name: "required",
    };

    const user = await dataValid(valid, req.body);

    try {
        

        if (user.data.password !== user.data.confirmPassword) {
            user.message.push("Password tidak sama");
        }

        if (user.message.length > 0) {
            return res.status(400).json({
                message: user.message,
            });
        }

        const usernameExist = await User.findAll({
            where: {
                username: user.data.username,
            },
        });

        const emailExist = await User.findAll({
            where: {
                email: user.data.email,
            },
        });

        if (usernameExist.length > 0) {
            return res.status(400).json({
                message: "Username telah digunakan",
            });
        }

        if (emailExist.length > 0) {
            return res.status(400).json({
                message: "Email telah digunakan",
            });
        }

        const hashedPassword = await bcrypt.hash(user.data.password, 10);
        const newUser = await User.create({
            username: user.data.username,
            password: hashedPassword,
            email: user.data.email,
            name: user.data.name,
        });

        return res.status(201).json({
            message: "success",
            data: newUser,
        });
    } catch (error) {
        console.log("Error di register", error);
    }
};

const login = async (req, res) => {
    const valid = {
        username: "required",
        password: "required",
    };

    const user = await dataValid(valid, req.body);

    try {
        if (user.message.length > 0) {
            return res.status(400).json({
                message: user.message,
            });
        }

        const foundUser  = await User.findOne({
            where: {
                username: user.data.username,
            },
        });

        if (!foundUser ) {
            return res.status(400).json({
                message: "Username atau password salah",
            });
        }

        const isPasswordValid = await bcrypt.compare(user.data.password, foundUser .password);

        if (!isPasswordValid) {
            return res.status(400).json({
                message: "Username atau password salah",
            });
        }

        const token = jwt.sign(
            { id: foundUser .id, username: foundUser .username },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        return res.status(200).json({
            message: "Login berhasil",
            token: token,
        });
    } catch (error) {
        console.log("Error di login", error);
        return res.status(500).json({
            message: "Terjadi kesalahan saat login",
        });
    }
}; 

module.exports = { register, login };
