const express = require("express");
const route = require('./routes/index')
const db = require('./config/db');
require('dotenv').config();
// const bodyParser = require('body-parser')

db.sync({})
  .then(() => {
    console.log('Tabel telah dibuat di database');
  })
  .catch((err) => {
    console.log('Error membuat tabel di database', err);
  });

const PORT = process.env.PORT;
const app = express();

app.use(express.json())
app.use(route)

app.listen(PORT, () => {
    console.log(`Server running on port: ${PORT}`);
});
